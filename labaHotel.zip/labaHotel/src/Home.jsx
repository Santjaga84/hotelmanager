import Auth from "./pages/auth";

const Home = () => {
  return(
    <>
      <Auth />
    </>
  );
};

export default Home;