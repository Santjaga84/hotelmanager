import { USER_LOADER, LOAD_USERS_SUCCESS, LOAD_USERS_FAILURE } from "../actions/userActions";

const initialUserState = {
  // users: [],
  // status: null,
  // error: null,
};

//reducer
export function userReducer(state = initialUserState,action){
  switch(action.type){
    
    case USER_LOADER:
      return {
        ...state,
        users: action.payload,
      }
    case LOAD_USERS_SUCCESS: {
            return {
                ...state,
                loading: false,
                data: action.payload,
            };
        }

    case LOAD_USERS_FAILURE: {
            return {
                ...state,
                loading: false,
                error: action.payload,
            };
        }

    default:
            return state;
    }
}
